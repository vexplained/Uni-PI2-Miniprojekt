package de.vexplained.libraries.cvs_graphics_library.stdGraphics;

public interface ITickable
{
	public void tick();
}
