/**
 * 
 */
module ProjectNBodySim
{
	requires java.desktop;
}