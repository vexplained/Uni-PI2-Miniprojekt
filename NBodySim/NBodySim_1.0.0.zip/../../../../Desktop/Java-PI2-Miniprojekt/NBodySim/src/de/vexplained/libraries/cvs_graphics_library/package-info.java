/**
 * (Parts of) A simple Swing-based graphics library for displaying dynamic content on a canvas.
 * 
 * @author Levin Fober
 */
package de.vexplained.libraries.cvs_graphics_library;