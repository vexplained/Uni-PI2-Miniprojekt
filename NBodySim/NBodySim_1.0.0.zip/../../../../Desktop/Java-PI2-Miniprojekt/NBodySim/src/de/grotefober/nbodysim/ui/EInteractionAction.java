package de.grotefober.nbodysim.ui;

public enum EInteractionAction
{
	NONE, ADD_OBJECT, DELETE_OBJECT;
}
