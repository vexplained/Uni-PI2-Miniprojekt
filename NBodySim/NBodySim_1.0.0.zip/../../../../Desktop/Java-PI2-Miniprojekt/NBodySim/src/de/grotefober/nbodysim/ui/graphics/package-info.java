/**
 * @deprecated Not implemented. Instead, the implementation of {@linkplain de.vexplained.libraries.cvs_graphics_library}
 *             should be used.
 */
@Deprecated
package de.grotefober.nbodysim.ui.graphics;